This folder is meant for property editors that are available at runtime.

If the property editor depends on the Delphi IDE, then the unit should be put in "GLScene\Source\DesignTime" instead of here.