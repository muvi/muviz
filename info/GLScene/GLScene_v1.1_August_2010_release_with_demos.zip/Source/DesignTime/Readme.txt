This folder is meant for units that rely on the Delphi IDE.

If property editor forms are available at run-time, then the form unit can be put in "GLScene\Source\PropertyEditors" instead of here.

