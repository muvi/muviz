For all this demos, i suppose that the directory BCBDemos are in the GLScene directory
and GLScene are in D:\Composants\BCB6\
1- the header files are in D:\Composants\BCB6\include
2- the lib files are in D:\Composants\BCB6\lib
3- the dcu/obj files are in D:\Composants\BCB6\dcu

Please, for each project, edit the options and correct the include and lib path 
according to your configuration.

Library directory contains some usefull library

