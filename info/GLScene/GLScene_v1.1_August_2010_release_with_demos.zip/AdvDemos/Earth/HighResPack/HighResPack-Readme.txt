High-Resolution resources pack for GLScene "Earth" demo.

This archive contains high-resolution texture backs and
stars database for the GLScene "Earth" demo. Place the
files in the demo's directory, and hit 'H' in the demo
to load them.

The files are individually tested in the demo, so if you 
don't want to load one of the high-resolution resources
(to reduce memory requirements or performance impact for 
instance), just delete or rename the corresponding file.

See the Demo's main Readme.txt for further details and credits.

Eric Grange
http://glscene.org