Panoramic Viewer Demo (with Source)

See Unit1.pas header & code for more details.

Eric Grange
http://glscene.org