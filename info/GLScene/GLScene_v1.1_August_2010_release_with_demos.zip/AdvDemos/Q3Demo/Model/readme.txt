Place she'k.pk3 file into the baseq3 folder.
Also you may need to create a Baseq3/models/players/she'k if you are having problems
seeing the icons in the characters select screen.

December 9, 1999
================================================================
Model Name:		She'k
Pack file:		baseq3/she'k.pk3
Author:			ALPHAwolf
Skin Author:		ALPHAwolf
Shaders 		Npherno
Email Address:		ALPHAwolf@Planatquake.com  ALPHAwolf@Wolfdenstudios.com

                        http://www.planetquake.com/Q2pmp/hostings/Alphawolf/

                        Http://www.Wolfdenstudios.com

Model description       : A Warrior class of the race known as Mon.



Additional Credits to   : id Software 

Thanks to:
Npherno for the tools and help.
R13
And the people that help me test it..:)



================================================================
  More on the way

