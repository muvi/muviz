GLScene - Advanced Demos
http://glscene.org

Source released under MPL, ressources may be under
different licences (check for each project).

Eric Grange