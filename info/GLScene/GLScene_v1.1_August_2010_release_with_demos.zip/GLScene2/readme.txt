GLScene 2 Experimentation / Draft implementation Directory

Files in this directory will be moved around, dropped, removed,
re-added, lost, found, stamped then dropped again, and hopefully,
cleanly structured the day the dust will have settled, fog will
have dispersed, and peace will be upon earth.