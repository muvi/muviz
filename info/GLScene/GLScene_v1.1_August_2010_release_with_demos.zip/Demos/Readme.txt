Samples/Demos for GLScene

These samples may not be a great piece of eye candy
[some are ;)], but have a look at the .pas/.dfm files,
and you will see  that very little code is needed to
achieve simple tasks.

If you want to compile all of the demos, you may use
the bpg (close Delphi in between, when compiling BPGs
D5-D7 leak heaps of memory and get awfully slow).

Enjoy :)

Eric Grange
egrange@glscene.org

All these files are released under GNU GPL.
GLScene is an open-source, Delphi 5/6/7 project released 
under Mozilla PL.

http://glscene.org
